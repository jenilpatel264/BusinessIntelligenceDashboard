package com.project.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.dao.StopwordDAO;
import com.project.model.StopwordVO;

@Service
public class StopwordServiceImpl implements StopwordService {

	@Autowired
	StopwordDAO stopwordDAO;

	@Transactional
	public void saveStopword(StopwordVO stopwordVO) {

		this.stopwordDAO.saveStopword(stopwordVO);

	}

	@Transactional
	public List<StopwordVO> getStopword() {
		
		return  this.stopwordDAO.getStopword();
	}
	@Transactional
	public List<StopwordVO> getStopwordById(StopwordVO stopwordVO) {
		
		return  this.stopwordDAO.getStopwordById(stopwordVO);
	}
	@Transactional
	public void updateStopword(StopwordVO stopwordVO) {

		this.stopwordDAO.updateStopword(stopwordVO);

	}

}
