package com.project.service;

import java.util.Date;
import java.util.GregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.persistence.Column;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.dao.CrawlDataDAO;
import com.project.dao.KeywordDAO;
import com.project.dao.StopwordDAO;
import com.project.model.CrawlPatternVO;
import com.project.model.FinalAbstractVO;
import com.project.model.KeywordCountVO;
import com.project.model.KeywordVO;
import com.project.model.PatternVO;
import com.project.model.StopwordVO;
import com.project.model.TrendVO;
import com.project.utils.BaseMethods;

@Service
@Transactional
public class CrawlDataServiceImpl implements CrawlDataService {

	@Autowired
	private BaseMethods baseMethods;
	@Autowired
	private CrawlDataDAO CrawlDataDAO;
	@Autowired
	KeywordDAO keywordDAO;
	@Autowired
	StopwordDAO stopwordDAO;

	@Transactional
	public void getCrawlData(String TrendName, String link, int pageno, TrendVO trendVO) {

		Map<String, Object> map = this.baseMethods.crawlData(TrendName, link, pageno);

		List<String> patternList = (List) map.get("patternList");
		List<PatternVO> patterndatalist = (List) map.get("patterndatalist");

		List id1 = this.CrawlDataDAO.getTrend(trendVO);
		int id = (Integer) id1.get(0);
		System.out.println(id);

		System.out.println("list:" + patternList.size());
		trendVO.setId(id);

		for (String string : patternList) {
			CrawlPatternVO crawlPatternVO = new CrawlPatternVO();
			crawlPatternVO.setTrendVO(trendVO);
			// System.out.println(string);
			crawlPatternVO.setLink(string);
			this.CrawlDataDAO.saveTrend(crawlPatternVO);
		}

		for (PatternVO patternVO : patterndatalist) {
			patternVO.setTrendVO(trendVO);
			this.CrawlDataDAO.savePattern(patternVO);
		}
	}

	@Transactional
	public List<CrawlPatternVO> getCrawlPatternByTopic(TrendVO trendVO) {
		// TODO Auto-generated method stub
		return this.CrawlDataDAO.getCrawlPatternByTopic(trendVO);
	}

	@Transactional
	public List<PatternVO> getPatternDetailsByTopic(TrendVO trendVO) {
		// TODO Auto-generated method stub
		return this.CrawlDataDAO.getPatternDetailsByTopic(trendVO);
	}

	@Transactional
	public List<PatternVO> getPatternDetails(PatternVO patternVO) {
		// TODO Auto-generated method stub
		return this.CrawlDataDAO.getPatternDetails(patternVO);
	}

	@Transactional
	public void getAbstarctByTopic(TrendVO trendVO) {
		List<PatternVO> abstractList = this.CrawlDataDAO.getAbstarctByTopic(trendVO);
		List<StopwordVO> stopwordList = this.stopwordDAO.getStopword();

		System.out.println(stopwordList.size());
		// trendVO.isStatus();
		System.err.println(abstractList.size());
		List<String> stopword = new ArrayList<String>();
		List<Integer> id = new ArrayList<Integer>();

		List<String> abstractname = new ArrayList<String>();
		for (StopwordVO stopwordVO : stopwordList) {
			stopword.add(stopwordVO.getStopWord().toLowerCase());
		}
		for (PatternVO patternVO : abstractList) {
			abstractname.add(patternVO.getPattentAbstract().toLowerCase());
			id.add(patternVO.getId());

		}
		String stopwords[] = new String[stopword.size()];
		stopwords = stopword.toArray(stopwords);
		ArrayList<String> wordsList = new ArrayList<String>();

		for (int i = 0; i < abstractname.size(); i++) {
			if (!(abstractname.isEmpty())) {
				PatternVO patternvo = new PatternVO();
				int patternid = id.get(i);
				System.err.println(patternid + " ");
				patternvo.setId(patternid);

				String finalabstract = abstractname.get(i);
				finalabstract = finalabstract.trim().replaceAll("/[, ]+/g", " ");

				String[] words = finalabstract.split(" ");
				if ((words.length) >= 2) {

					for (String word : words) {

						wordsList.add(word);
						// System.err.println(word);
					}
					System.err.println(wordsList.size());
					for (int k = 0; k < wordsList.size(); k++) {
						for (int j = 0; j < stopwords.length; j++) {
							if (stopwords[j].contains(wordsList.get(k))) {

								wordsList.remove(k);

							}
						}

					}
				} else {
					wordsList.add("");
				}

				StringBuilder sb = new StringBuilder();

				for (String str : wordsList) {
					sb.append(str + " ");

				}
				System.out.println(sb.toString());
				FinalAbstractVO finalAbstractVO = new FinalAbstractVO();
				finalAbstractVO.setFinalabstract(sb.toString());
				finalAbstractVO.setTrendVO(trendVO);
				finalAbstractVO.setPatternVO(patternvo);
				System.err.println("asdas  " + patternvo);
				this.CrawlDataDAO.saveFinalAbstract(finalAbstractVO);
			}
			wordsList.clear();
			System.err.println();
		}

	}

	@Transactional
	public void getfinalabstract(TrendVO trendVO) {
		// TODO Auto-generated method stub
		System.out.println("as");
		List<FinalAbstractVO> finalabstractList = this.CrawlDataDAO.getfinalabstract(trendVO);
		List<PatternVO> abstractList = this.CrawlDataDAO.getAbstarctByTopic(trendVO);
		System.out.println(finalabstractList.size());
		List<KeywordVO> keywordList = this.keywordDAO.getKeywordByTopic(trendVO);
		System.out.println(keywordList.size());
		List<String> abstractname = new ArrayList<String>();
		List<Integer> filleddate = new ArrayList<Integer>();
		List id = new ArrayList<Object>();
		List<String> keywordname = new ArrayList<String>();
		ArrayList<Integer> patternyear = new ArrayList<Integer>();
		patternyear.add(2016);
		patternyear.add(2017);
		patternyear.add(2018);
		patternyear.add(2019);
		patternyear.add(2020);

		for (FinalAbstractVO finalAbstractVO : finalabstractList) {

			abstractname.add(finalAbstractVO.getFinalabstract());
			// System.out.println(finalAbstractVO.getId()+"
			// "+finalAbstractVO.getFinalabstract());

		}
		for (PatternVO patternVO : abstractList) {
			String string = patternVO.getFileddate();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);
			LocalDate date = LocalDate.parse(string, formatter);

			filleddate.add(date.getYear());

		}
		for (KeywordVO keywordVO : keywordList) {

			keywordname.add(keywordVO.getKeyword());
			System.out.println(keywordVO.getKeyword());
		}

		int count;

		// System.out.println("adaasd" + patternyear.get(3));
		for (int keywordindex = 0; keywordindex < keywordname.size(); keywordindex++) {
			count = 0;

			for (int yearindex = 0; yearindex < patternyear.size(); yearindex++) {
				count = 0;
				String keyword = keywordname.get(keywordindex).replaceAll(" ", "");
				// System.out.println(key);
				for (int finalabstract = 0; finalabstract < abstractname.size(); finalabstract++) {
					String ab = abstractname.get(finalabstract);
					// System.out.println(filleddate.get(finalabstract));

					for (int n = 1; n <= 3; n++) {
						for (String ngram : Ngrams(n, ab)) {
							// System.out.print(ngram+" ");

							if (patternyear.get(yearindex).equals(filleddate.get(finalabstract))) {
								if (keyword.equals(ngram)) {

									count++;
								}
							}
						}
					}

				}

				KeywordCountVO keywordCountVO = new KeywordCountVO();
				keywordCountVO.setKeyword(keywordname.get(keywordindex));
				keywordCountVO.setPatternyear(patternyear.get(yearindex));
				keywordCountVO.setCount(count);
				keywordCountVO.setTrendVO(trendVO);
				this.CrawlDataDAO.saveKeywordCount(keywordCountVO);

				// System.out.println(trendVO.getId());
				// System.out.println();
				System.out.println(patternyear.get(yearindex));
				System.out.println(keywordname.get(keywordindex) + " " + count);

			}

		}

	}

	private List<String> Ngrams(int number, String str) {
		// TODO Auto-generated method stub
		ArrayList<String> ngms = new ArrayList<String>();
		String s1[] = str.split("[\\s.,]+");
		for (int i = 0; i < s1.length - number + 1; i++) {
			ngms.add(concat1(s1, i, i + number));

		}

		return ngms;

	}

	private String concat1(String[] words, int start, int end) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		for (int i = start; i < end; i++) {

			sb.append(words[i]);

		}
		return sb.toString();
	}

	@Override
	public List getCount(TrendVO trendVO) {
		return this.CrawlDataDAO.getCount(trendVO);
	}

	@Override
	public List getCountFromYear(KeywordVO keywordVO) {
		// TODO Auto-generated method stub
		return this.CrawlDataDAO.getCountFromYear(keywordVO);
	}

//		List<String> keywordname = new ArrayList<String>();
//		List<KeywordVO> keywordList = this.keywordDAO.getKeywordByTopic(trendVO);

//		for (KeywordVO keywordVO : keywordList) {
//
//			keywordname.add(keywordVO.getKeyword());
//			System.out.println(keywordVO.getKeyword());
//		}
//		for (int keywordindex = 0; keywordindex < keywordname.size(); keywordindex++) {
//
//			KeywordVO keywordVO = new KeywordVO();
//			keywordVO.setKeyword(keywordname.get(keywordindex));
//
//			List<Integer> countList = this.CrawlDataDAO.getCount(keywordVO);
//			// System.err.println(keywordname.size());
//			System.out.println(keywordname.get(keywordindex) + " " + countList.get(0));
//		}
	
		//System.out.println("count List: "+keywordcount.size());
		
//		ArrayList<Integer> patternyear = new ArrayList<Integer>();
//		patternyear.add(2016);
//		patternyear.add(2017);
//		patternyear.add(2018);
//		patternyear.add(2019);
//		patternyear.add(2020);
//		for (int keywordindex = 0; keywordindex < keywordname.size(); keywordindex++) {
//			
//			for (int patternindex = 0; patternindex < patternyear.size(); patternindex++) {
//				KeywordCountVO keywordCountVO=new KeywordCountVO();
//				keywordCountVO.setKeyword(keywordname.get(keywordindex));
//				keywordCountVO.setPatternyear(patternyear.get(patternindex));
//				List<Integer> countList =	this.CrawlDataDAO.getCountFromYear(keywordCountVO);
//				
//				System.err.println(countList.get(2));
//			}
//		
//		List countList =	this.CrawlDataDAO.getCountFromYear();
//		System.out.println(countList.size());
//	

	
		

}
