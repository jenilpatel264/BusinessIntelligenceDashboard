package com.project.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.project.DTO.MenuDTO;
import com.project.model.KeywordVO;
import com.project.model.TrendVO;
import com.project.service.CrawlDataService;
import com.project.service.KeywordService;
import com.project.service.TrendService;

@RestController
public class UserController {
	@Autowired
	private TrendService TrendService;
	@Autowired
	private KeywordService KeywordService;
	@Autowired
	private CrawlDataService crawlDataService;

	@GetMapping(value = "userViewTrend")
	public ResponseEntity userViewTrend() {
		List<TrendVO> trendList = this.TrendService.getTrend();
		List<KeywordVO> keywordList = this.KeywordService.getKeyword();

		System.out.println(trendList);

		List<MenuDTO> menuDTOList = new ArrayList();

		for (TrendVO trendVO : trendList) {
			MenuDTO menuDTO = new MenuDTO();
			menuDTO.setTrend(trendVO);
			List<KeywordVO> keyWords = keywordList.stream()
					.filter(keyword -> keyword.getTrendVO().getId() == trendVO.getId()).collect(Collectors.toList());
			menuDTO.setKeywordVOList(keyWords);
			menuDTOList.add(menuDTO);
		}

		return new ResponseEntity(menuDTOList, HttpStatus.OK);
	}

	@GetMapping(value = "userViewKeyword")
	public ModelAndView userViewKeyword(@RequestParam int id, TrendVO trendVO) {

		System.out.println(id);
		trendVO.setId(id);
		List keywordList = this.crawlDataService.getCount(trendVO);
		System.out.println(keywordList.size());

		return new ModelAndView("index", "keywordList", keywordList);
	}

	@GetMapping(value = "viewKeywordYear")
	public ModelAndView viewKeywordYear(@RequestParam String keyword, KeywordVO keywordVO) {
		keywordVO.setKeyword(keyword);
		List keywordYearList = this.crawlDataService.getCountFromYear(keywordVO);
		System.out.println(keywordYearList.size());

		return new ModelAndView("viewkeywordyear","keywordYearList",keywordYearList);
	}
	@GetMapping(value = "dashboard")
	public ModelAndView dashboard() {
		List<TrendVO> trendList = this.TrendService.getTrend();

		return new ModelAndView("dashboard","trendList",trendList);
	}

}
