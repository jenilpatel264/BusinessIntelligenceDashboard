package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.model.TrendVO;
import com.project.service.TrendService;

@Controller
public class TrendController {

	@Autowired
	private TrendService TrendService;

	@GetMapping(value = "admin/addTrend")
	public ModelAndView addTrend() {
		System.out.println("1");
		return new ModelAndView("admin/addTrend", "TrendVO", new TrendVO());
	}

	@PostMapping(value = "admin/saveTrend")
	public ModelAndView saveTrend(@ModelAttribute TrendVO TrendVO) {
		if (TrendVO.getTrendName() != "" && TrendVO.getTrendDescription() != "") {
			TrendVO.setStatus(true);
			this.TrendService.saveTrend(TrendVO);
		}
		return new ModelAndView("redirect:viewTrend");
	}

	@GetMapping(value = "admin/viewTrend")
	public ModelAndView viewTrend(TrendVO trendVO) {
		List<TrendVO> trendList = this.TrendService.getTrend();
		trendVO.isStatus();
		return new ModelAndView("admin/viewTrend", "trendList", trendList);
	}

	@GetMapping(value = "admin/editTrend")
	public ModelAndView editTrend(@RequestParam int id, TrendVO trendVO) {
		trendVO.setId(id);
		trendVO.isStatus();
		List<TrendVO> trendList = this.TrendService.getTrendById(trendVO);
		return new ModelAndView("admin/addTrend", "TrendVO", trendList.get(0));
	}

	@GetMapping(value = "admin/deleteTrend")
	public ModelAndView deleteTrend(@RequestParam int id, TrendVO trendVO) {
		trendVO.setId(id);

		List<TrendVO> trendList = this.TrendService.getTrendById(trendVO);

		System.out.println(id);
		TrendVO trendVO2 = trendList.get(0);
		trendVO2.setStatus(false);
		System.out.println(trendVO2);
		this.TrendService.saveTrend(trendVO2);

		return new ModelAndView("redirect:viewTrend");
	}

}
