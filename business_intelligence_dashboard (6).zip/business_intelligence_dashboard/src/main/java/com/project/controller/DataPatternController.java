package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.project.model.CrawlPatternVO;
import com.project.model.PatternVO;
import com.project.model.TrendVO;
import com.project.service.CrawlDataService;
import com.project.service.StopwordService;
import com.project.service.TrendService;

@RestController
public class DataPatternController {
	
	@Autowired
	private TrendService TrendService;
 
	@Autowired
	private CrawlDataService crawlDataService; 
	
	@Autowired
	private StopwordService stopwordService;

	@GetMapping(value = "admin/crawlData")
	public ModelAndView viewTrend(TrendVO trendVO) {
		List<TrendVO> trendList = this.TrendService.getTrend();
		// trendVO.isStatus();
		return new ModelAndView("admin/crawlData", "trendList", trendList);
	}

	@PostMapping(value = "admin/getDataPattern")
	public ModelAndView GetDataPattern(@RequestParam String link, @RequestParam int pageno,
			@RequestParam String trendName) {

		TrendVO trendVO = new TrendVO();
		trendVO.setTrendName(trendName);

		this.crawlDataService.getCrawlData(trendName, link, pageno, trendVO);
		// this.crawlDataService.getTrendId(trendName, trendVO);
		return new ModelAndView("admin/viewKeyword");
	}

	@GetMapping(value = "admin/viewUrlPattern")
	public ModelAndView viewDataPattern() {
		List<TrendVO> trendList = this.TrendService.getTrend();
		return new ModelAndView("admin/viewUrlPattern", "trendList", trendList);
	}

	@GetMapping(value = "admin/findUrlPatternById")
	public ResponseEntity findCrawlPatternById(@RequestParam int id, TrendVO trendVO, CrawlPatternVO crawlPatternVO,
			PatternVO addPatternVO) {
		trendVO.setId(id);
		List<CrawlPatternVO> crawlpatternList = this.crawlDataService.getCrawlPatternByTopic(trendVO);
		return new ResponseEntity(crawlpatternList, HttpStatus.OK);
	}

	@GetMapping(value = "admin/viewPatternDetails")
	public ModelAndView viewPatternDetails() {
		List<TrendVO> trendList = this.TrendService.getTrend();
		System.err.println("asdas");
		return new ModelAndView("admin/viewPatternDetails", "trendList", trendList);
	}

	@GetMapping(value = "admin/PatternDetailsById")
	public ResponseEntity patternDetailsById(@RequestParam int id, TrendVO trendVO, PatternVO patternVO) {
		trendVO.setId(id);
		System.err.println("asdas");
		List<PatternVO> patterndetailsList = this.crawlDataService.getPatternDetailsByTopic(trendVO);

		System.out.println(patterndetailsList);
		return new ResponseEntity(patterndetailsList, HttpStatus.OK);
	}

	@GetMapping(value = "admin/DetailsById")
	public ResponseEntity DetailsById(@RequestParam int id, PatternVO patternVO) {
		patternVO.setId(id);
		List<PatternVO> patterndetailsList = this.crawlDataService.getPatternDetails(patternVO);
		System.out.println(patterndetailsList);
		return new ResponseEntity(patterndetailsList, HttpStatus.OK);
	}

	@GetMapping(value = "admin/analysis")
	public ModelAndView analysis(TrendVO trendVO) {
		List<TrendVO> trendList = this.TrendService.getTrend();
		return new ModelAndView("admin/analysis", "trendList", trendList);
	}

	@GetMapping(value = "admin/finalabstract")
	public ModelAndView finalabstract(TrendVO trendVO, @RequestParam int id, PatternVO patternVO) {
		trendVO.setId(id);
		this.crawlDataService.getAbstarctByTopic(trendVO);
		return new ModelAndView("admin/analysis");
	}

	@GetMapping(value = "admin/countkeyword")
	public ModelAndView countkeyword(TrendVO trendVO, @RequestParam int id, PatternVO patternVO) {
		trendVO.setId(id);
		this.crawlDataService.getfinalabstract(trendVO);
		List trendList=this.crawlDataService.getCount(trendVO);
		return new ModelAndView("admin/analysis");
	}

}
