package com.project.DTO;

import java.util.List;

import com.project.model.KeywordVO;
import com.project.model.TrendVO;

public class MenuDTO {

	private TrendVO trend;
	private List<KeywordVO> keywordVOList;

	public TrendVO getTrend() {
		return trend;
	}

	public void setTrend(TrendVO trend) {
		this.trend = trend;
	}

	public List<KeywordVO> getKeywordVOList() {
		return keywordVOList;
	}

	public void setKeywordVOList(List<KeywordVO> keywordVOList) {
		this.keywordVOList = keywordVOList;
	}

}
