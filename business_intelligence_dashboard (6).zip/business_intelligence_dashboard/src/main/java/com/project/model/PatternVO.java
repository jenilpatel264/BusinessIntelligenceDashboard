package com.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "pattern_details_table")
public class PatternVO {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "united_state_patent_no")
	private String unitedstatepatentNo;

	@Column(name = "pattern_date")
	private String date;

	@Column(name = "title")
	private String title;

	@Column(name = "abstract")
	private String pattentAbstract;

	@Column(name = "applicant_name")
	private String applicantname;

	@Column(name = "applicant_city")
	private String applicantcity;

	@Column(name = "applicant_state")
	private String applicantstate;

	@Column(name = "applicant_country")
	private String applicantcountry;

	@Column(name = "applicant_type")
	private String applicanttypes;

	@Column(name = "assignee")
	private String assignee;

	@Column(name = "family_id")
	private String familyid;

	@Column(name = "filed_date")
	private String fileddate;

	@Column(name = "pct_filed_date")
	private String pctfileddate;

	@Column(name = "Pct_no")
	private String pctno;

	@Column(name = "pct_publication_date")
	private String pctpublicationDate;

	@Column(name = "Pct_Publication_No")
	private String pctpublicationNo;

	@Column(name = "Inventors")
	private String inventors;

	@Column(name = "Application_no")
	private String applicationno;
	

	@ManyToOne
	@JoinColumn(name = "trend_id")
	private TrendVO trendVO;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUnitedstatepatentNo() {
		return unitedstatepatentNo;
	}

	public void setUnitedstatepatentNo(String unitedstatepatentNo) {
		this.unitedstatepatentNo = unitedstatepatentNo;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date2) {
		this.date = date2;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPattentAbstract() {
		return pattentAbstract;
	}

	public void setPattentAbstract(String pattentAbstract) {
		this.pattentAbstract = pattentAbstract;
	}

	public String getApplicantname() {
		return applicantname;
	}

	public void setApplicantname(String applicantname) {
		this.applicantname = applicantname;
	}

	public String getApplicantcity() {
		return applicantcity;
	}

	public void setApplicantcity(String applicantcity) {
		this.applicantcity = applicantcity;
	}

	public String getApplicantstate() {
		return applicantstate;
	}

	public void setApplicantstate(String applicantstate) {
		this.applicantstate = applicantstate;
	}

	public String getApplicantcountry() {
		return applicantcountry;
	}

	public void setApplicantcountry(String applicantcountry) {
		this.applicantcountry = applicantcountry;
	}

	public String getApplicanttypes() {
		return applicanttypes;
	}

	public void setApplicanttypes(String applicanttypes) {
		this.applicanttypes = applicanttypes;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getFamilyid() {
		return familyid;
	}

	public void setFamilyid(String familyid) {
		this.familyid = familyid;
	}

	public String getFileddate() {
		return fileddate;
	}

	public void setFileddate(String fileddate) {
		this.fileddate = fileddate;
	}

	public String getPctfileddate() {
		return pctfileddate;
	}

	public void setPctfileddate(String pctfileddate) {
		this.pctfileddate = pctfileddate;
	}

	public String getPctno() {
		return pctno;
	}

	public void setPctno(String pctno) {
		this.pctno = pctno;
	}

	public String getPctpublicationDate() {
		return pctpublicationDate;
	}

	public void setPctpublicationDate(String pctpublicationDate) {
		this.pctpublicationDate = pctpublicationDate;
	}

	public String getPctpublicationNo() {
		return pctpublicationNo;
	}

	public void setPctpublicationNo(String pctpublicationNo) {
		this.pctpublicationNo = pctpublicationNo;
	}

	public String getApplicationno() {
		return applicationno;
	}

	public void setApplicationno(String applicationno) {
		this.applicationno = applicationno;
	}

	public String getInventors() {
		return inventors;
	}

	public void setInventors(String inventors) {
		this.inventors = inventors;
	}

	public TrendVO getTrendVO() {
		return trendVO;
	}

	public void setTrendVO(TrendVO trendVO) {
		this.trendVO = trendVO;
	}

}
