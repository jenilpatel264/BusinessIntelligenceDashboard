package com.project.dao;

import java.util.List;

import com.project.model.StopwordVO;

public interface StopwordDAO {
	public void saveStopword(StopwordVO stopwordVO);
	List<StopwordVO> getStopword();
	List<StopwordVO> getStopwordById(StopwordVO stopwordVO);
	public void updateStopword(StopwordVO stopwordVO);
	

}
