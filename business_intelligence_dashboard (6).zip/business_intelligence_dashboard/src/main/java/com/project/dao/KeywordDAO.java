package com.project.dao;

import java.util.List;

import com.project.model.KeywordVO;
import com.project.model.StopwordVO;
import com.project.model.TrendVO;


public interface KeywordDAO {
	public void saveKeyword(KeywordVO keywordVO);
	List<KeywordVO> getKeyword();
	List<KeywordVO> getKeywordByTopic(TrendVO trendVO);
	List<KeywordVO> getKeywordById(KeywordVO keywordVO);

	public void updateKeyword(KeywordVO keywordVO);
}
