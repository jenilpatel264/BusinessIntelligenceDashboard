package com.project.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.model.KeywordVO;
import com.project.model.StopwordVO;
import com.project.model.TrendVO;

@Repository
public class KeywordDAOImpl implements KeywordDAO {
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public void saveKeyword(KeywordVO keywordVO) {

		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(keywordVO);

	}

	@Override
	public List<KeywordVO> getKeyword() {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from KeywordVO where status=true");
		List<KeywordVO> keywordList = query.list();
		return keywordList;
		// TODO Auto-generated method stub

	}

	@Override
	public List<KeywordVO> getKeywordByTopic(TrendVO trendVO) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from KeywordVO where status=true and trendVO.id=" + trendVO.getId());
		System.out.println(query);
		List<KeywordVO> keywordList = query.list();
		return keywordList;

	}

	@Override
	public List<KeywordVO> getKeywordById(KeywordVO keywordVO) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from KeywordVO where status=true and id=" + keywordVO.getId());
		System.out.println(query);
		List<KeywordVO> keywordList = query.list();
		System.out.println(keywordList);
		return keywordList;
	}
	@Override
	public void updateKeyword(KeywordVO keywordVO) {

		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(keywordVO);

	}
}
