package com.project.dao;

import java.util.List;


import com.project.model.CrawlPatternVO;
import com.project.model.FinalAbstractVO;
import com.project.model.KeywordCountVO;
import com.project.model.KeywordVO;
import com.project.model.PatternVO;
import com.project.model.TrendVO;

public interface CrawlDataDAO {
	List<TrendVO> getTrend(TrendVO TrendVO);

	void saveTrend(CrawlPatternVO crawlPatternVO);
	void savePattern(PatternVO patternVO);
	void saveFinalAbstract(FinalAbstractVO finalAbstractVO);

	List<CrawlPatternVO> getCrawlPatternByTopic(TrendVO trendVO);
	List<PatternVO> getPatternDetailsByTopic(TrendVO trendVO);
	List<PatternVO> getPatternDetails(PatternVO patternVO);
	List<PatternVO> getAbstarctByTopic(TrendVO trendVO);
	List<FinalAbstractVO> getfinalabstract(TrendVO trendVO);
	void saveKeywordCount(KeywordCountVO keywordCountVO);
	List getCount(TrendVO trendVO);
	List getCountFromYear(KeywordVO keywordVO);
}
