function generateMenu() {

	$('#menu-id').html();

	var li = '<li class="sidebar-header mobile-only"><span>NAVIGATION</span></li>';

	li = li + '<li><a class="has-arrow" href="dashboard" aria-expanded="false">'
			+ '<i class="icon dripicons-meter"></i>'
			+ '<span class="hide-menu">Dashboard</span></a></li>';

	$('#menu-id').html(li);

	var htp = new XMLHttpRequest();

	htp.onreadystatechange = function() {
		if (htp.readyState == 4) {
			$('#menu-id').html();

			var jsn = JSON.parse(htp.responseText);

			for (var i = 0; i < jsn.length; i++) {

				var trend = jsn[i].trend;
				var keywordList = jsn[i].keywordVOList;
				
				li = li + '<li><a class="has-arrow" href="userViewKeyword?id='+trend.id+'" aria-expanded="false">'
				+ '<i class="icon dripicons-meter"></i>'
				+ '<span class="hide-menu" style="text-transform: capitalize;">'+trend.trendName+'</span></a>'
				+'<ul aria-expanded="false" class="collapse">';
				
				for(var index = 0 ; index <keywordList.length ; index++){
					li = li + '<li><a href="viewKeywordYear?keyword='+keywordList[index].keyword+'" style="text-transform: capitalize;">'+keywordList[index].keyword+'</a></li>';
					
					if(index == 4 ){
						li = li + '<li><a href="userViewKeyword?id='+trend.id+'">View More</a></li>';
						break;
					}
				}
				
				li = li + '</ul></li>';
						
			}

			$('#menu-id').html(li);
		}

	}
	htp.open("get", "userViewTrend", true);
	htp.send();

}



/*
 * <li><a class="has-arrow " href="#" aria-expanded="false"> <i class="icon
 * dripicons-folder"></i> <span class="hide-menu">Menu Levels</span> </a>
 * <ul aria-expanded="false" class="collapse"> <li><a
 * href="javascript:void(0);">Level 1.1</a></li> <li><a href="#"
 * class="has-arrow">Level 1.2</a> <ul aria-expanded="false" class="collapse">
 * <li><a href="javascript:void(0);">Level 2.1</a></li> <li><a href="#"
 * class="has-arrow">Level 2.2</a> <ul aria-expanded="false" class="collapse">
 * <li><a href="javascript:void(0);">Level 3.1</a></li> <li><a
 * href="javascript:void(0);">Level 3.2</a></li> <li><a
 * href="javascript:void(0);">Level 3.3</a></li> </ul></li> <li><a
 * href="javascript:void(0);">Level 2.3</a></li> </ul></li> <li><a
 * href="javascript:void(0);">Level 1.3</a></li> </ul></li>
 */