Highcharts.chart('container', {
    chart: {
        type: 'line'
    },
    title: {
        text: 'Keyword per Year'
    },
   
    xAxis: {
        categories: ['2016', '2017', '2018', '2019', '2020']
    },
    yAxis: {
        title: {
            text: 'Keyword(in numbers)'
        }
    },
    plotOptions: {
        line: {
            dataLabels: {
                enabled: true
            },
            enableMouseTracking: false
        }
    },
    series: [{
        name: 'Tokyo',
        data: [7.0, 6.9, 90.5, 14.5, 18.4]
    },
    ]
});