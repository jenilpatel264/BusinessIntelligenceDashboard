	function KeywordByTopic()
	{
		var KeywordTopic=document.getElementById("Keyword_Topic");
		var Table=document.getElementById("order-listing");
		
		var htp=new XMLHttpRequest();
	    
	    htp.onreadystatechange=function(){
	       
	        if(htp.readyState==4){
	        	var jsn=JSON.parse(htp.responseText);
	        	var	txt = '';
	        	
	        	for(var i=0;i<jsn.length;i++){
	        		txt= txt + '<tr>' + 
						'<td>'+ (i+1) + '</td>' + 
						'<td>'+jsn[i].keyword + '</td>'+
						'<td> <a href="editKeyword?id='+jsn[i].id+'">' + 
						     '<i class="mdi mdi-pencil-box-outline" style="font-size: 20px;"></i></a>'+
							'<a href="deleteKeyword?id='+jsn[i].id+'"><i class="mdi mdi-delete" style="font-size: 20px; margin-left: 10px; color: #f34949"></i></a> </td>';
				}
	        	$('#table1').html('').html(txt);
			
	        }
	    }
	
	    htp.open("get","findKeywordById?id="+KeywordTopic.value,true);
	    htp.send();
		
	}