	function PatternDetailsByTopic()
	{
		var PatternDetails=document.getElementById("PatternDetails_Topic");
		var Table=document.getElementById("order-listing");
		
		var htp=new XMLHttpRequest();
	    
	    htp.onreadystatechange=function(){
	       
	        if(htp.readyState==4){
	        	var jsn=JSON.parse(htp.responseText);
	        	var	txt = '';
	        	
	        	for(var i=0;i<jsn.length;i++){
	        		txt= txt + '<tr>' + 
	        		'<td>'+ (i+1) + '</td>' + 
	        		'<td>'+jsn[i].unitedstatepatentNo + '</td>'+
					'<td>'+jsn[i].title + '</td>'+
					'<td ><button type="button" onclick="topicdetails('+jsn[i].id+')" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#exampleModal-3" ><i class="mdi mdi-eye btn-icon-prepend"></i>View</button></td>';
						
				}
	        	$('#table1').html('').html(txt);
			
	        }
	    }
	
	    htp.open("get","PatternDetailsById?id="+PatternDetails.value,true);
	    htp.send();
		
	}
	function topicdetails(id)
	{
		var x = id;
	console.log('id', x);
	var htp = new XMLHttpRequest();

	htp.onreadystatechange = function() {
		if (htp.readyState == 4) {

			var jsn = JSON.parse(htp.responseText);

			for (var i = 0; i < jsn.length; i++) {

				var unitedstatepatentNo = jsn[i].unitedstatepatentNo;
				var date = jsn[i].date;
				var title = jsn[i].title;
				var pattentAbstract = jsn[i].pattentAbstract;
				var applicantname = jsn[i].applicantname;
				var applicantcity = jsn[i].applicantcity;
				var applicantstate = jsn[i].applicantstate;
				var applicantcountry = jsn[i].applicantcountry;
				var applicanttypes = jsn[i].applicanttypes;
				var assignee = jsn[i].assignee;
				var familyid = jsn[i].familyid;
				var fileddate = jsn[i].fileddate;
				var pctfileddate = jsn[i].pctfileddate;
				var pctno = jsn[i].pctno;
				var pctpublicationDate = jsn[i].pctpublicationDate;
				var pctpublicationNo = jsn[i].pctpublicationNo;
				var inventors = jsn[i].inventors;
				var applicationno= jsn[i].applicationno;
			
				
				

				$('#patternno').html(unitedstatepatentNo);
				$('#date').html(date);
				$('#title').html(title);
				$('#abstract').html(pattentAbstract);
				$('#inventors').html( inventors);
				$('#Applicantname').html(applicantname);
				$('#Applicantcountry').html(applicantcountry);
				$('#Applicantcity').html(applicantcity);
				$('#Applicantstate').html(applicantstate);
				$('#Applicanttype').html(applicanttypes);
				$('#Assignee').html(assignee);
				$('#FamilyID').html(familyid);
				$('#ApplNo').html(applicationno);
				$('#Filed').html(fileddate);
				$('#PCTFiled').html(pctfileddate);
				$('#PCTNo').html(pctno);
				$('#PCTPubNo').html(pctpublicationNo);
				$('#PCTPubDate').html(pctpublicationDate);
				

			}
	}
}
	    htp.open("get","DetailsById?id="+x,true);
	    htp.send();
	    
		}

